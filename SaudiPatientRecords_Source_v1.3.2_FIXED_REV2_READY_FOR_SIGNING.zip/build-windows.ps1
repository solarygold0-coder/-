$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$solution = Join-Path $root "PatientRecordsSaudi\PatientRecordsSaudi.sln"
$vswhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
if (-not (Test-Path $vswhere)) { throw "Visual Studio Build Tools are not installed." }
$msbuild = & $vswhere -latest -products * -requires Microsoft.Component.MSBuild -find MSBuild\**\Bin\MSBuild.exe | Select-Object -First 1
if (-not $msbuild) { throw "MSBuild was not found." }
& $msbuild $solution /t:Restore /p:Configuration=Release /m
if ($LASTEXITCODE -ne 0) { throw "Package restore failed." }
& $msbuild $solution /t:Build /p:Configuration=Release /m
if ($LASTEXITCODE -ne 0) { throw "Build failed." }
& (Join-Path $root "PatientRecordsSaudi.Tests\bin\Release\PatientRecordsSaudi.Tests.exe")
if ($LASTEXITCODE -ne 0) { throw "Safety tests failed." }
$out = Join-Path $root "release\App"
if (Test-Path $out) { Remove-Item $out -Recurse -Force }
New-Item -ItemType Directory -Force -Path $out | Out-Null
Copy-Item (Join-Path $root "PatientRecordsSaudi\bin\Release\*") $out -Recurse -Force
Get-ChildItem $out -Filter *.pdb -Recurse | Remove-Item -Force
$applicationExe = Get-ChildItem -LiteralPath $out -Filter *.exe -File | Select-Object -First 1
if (-not $applicationExe) { throw "The application EXE was not produced." }
Write-Host "Build succeeded: $out"
